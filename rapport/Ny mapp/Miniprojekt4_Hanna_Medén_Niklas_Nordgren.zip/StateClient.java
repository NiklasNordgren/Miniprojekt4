

public interface StateClient {
	
	public void pointerDown(Point point);

}
